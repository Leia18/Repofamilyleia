import xbmcaddon
import urllib, os,re,urllib2
import xbmc,xbmcgui
import subprocess
import zipfile
import stat
import shutil
import time


""" BOTONES GUI"""


addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')


""" DETECTAR SO Y PONER RUTAS"""


line9 = 'NO Soportado'
line10 = 'Solo armv7 o aarch64'
line11 = 'Solo Linux'

if xbmc.getCondVisibility('system.platform.linux') and not xbmc.getCondVisibility('system.platform.Android'):
	if "arm" in os.uname()[4]:
		ruta = xbmc.translatePath("special://home")
		rutaacestream = os.path.join(os.sep, ruta, "userdata", "addon_data", "program.plexus", "acestream")
	elif "aarch" in os.uname()[4]:
		ruta = "/storage/.config"
		rutaacestream = "/storage/.config/acestream"
	else :
		xbmcgui.Dialog().ok(addonname, line9, line10)
		exit()
else :
	xbmcgui.Dialog().ok(addonname, line9, line11)
	exit()	


""" PARAR Y ELIMINAR ACESTREAM """

if "arm" in os.uname()[4]:
	if os.geteuid() == 0 :
		subprocess.call(["pkill", "acestream"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/proc"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/sys"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/dev"])
		time.sleep(0.1)
		shutil.rmtree(rutaacestream)
	else :
		subprocess.call(["sudo", "pkill", "acestream"])
		subprocess.call(["sudo", "umount", "-l", rutaacestream+"/androidfs/proc"])
		subprocess.call(["sudo", "umount", "-l", rutaacestream+"/androidfs/sys"])
		subprocess.call(["sudo", "umount", "-l", rutaacestream+"/androidfs/dev"])	
		time.sleep(0.1)
		subprocess.call(["sudo", "rm", "-rf", rutaacestream])
else:
	if os.path.exists(rutaacestream):
		subprocess.call(["pkill", "acestream"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/proc"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/sys"])
		subprocess.call(["umount", "-l", rutaacestream+"/androidfs/dev"])
		time.sleep(0.1)
		shutil.rmtree(rutaacestream)
	else:
		pass		
		
	
time.sleep(0.1)
os.mkdir(rutaacestream, 0777)


""" INICIO """


line1 = 'Bienvenido a Plexus-Patcher by Coeman76'
line2 = 'Pulse OK para comenzar'
xbmcgui.Dialog().ok(addonname, line1, line2)


""" DESCARGAR ACESTREAM """

def DownloaderClass(url,dest):
	dp = xbmcgui.DialogProgress()
	dp.create("Plexus-Patcher","Descargando Acestream...")
	urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
        	percent = min((numblocks*blocksize*100)/filesize, 100)
        	print percent
        	dp.update(percent)
    	except:
        	percent = 100
		dp.update(percent)

if "arm" in os.uname()[4]:
	url ='http://acestreampi.ddns.net/NoTocar/acestream.zip'
	DownloaderClass(url, ruta+"/userdata/acestream.zip")
elif "aarch" in os.uname()[4]:
	url ='http://acestreampi.ddns.net/NoTocar/acestream1.zip'
	DownloaderClass(url, ruta+"/acestream1.zip")
else:
	pass

""" DESCOMPRIMIR """


pDialog = xbmcgui.DialogProgress()
pDialog.create("Plexus-Patcher","Descarga Completa!")
time.sleep(1.5)
pDialog.update(25, "Descomprimiendo Archivos...")

if "arm" in os.uname()[4]:

	zf=zipfile.ZipFile(ruta+'/userdata/acestream.zip', 'r')

	for i in zf.namelist():
		zf.extract(i, path=ruta+'/userdata/addon_data/program.plexus')
else:
	zf=zipfile.ZipFile(ruta+'/acestream1.zip', 'r')

	for i in zf.namelist():
		zf.extract(i, path=ruta)
	
pDialog.update(50, "Estableciendo Permisos...")


""" AUTOSTART AMLOGIC"""


if "aarch" in os.uname()[4]:
	file = open(ruta+"/autostart.sh", "w")
	file.write("#!/bin/sh" + os.linesep)
	file.write("(" + os.linesep)
	file.write("/storage/.config/acestream/autostart.sh" + os.linesep)
	file.write(")&")
	file.close()	


""" PERMISOS"""


time.sleep(1)
if os.geteuid() == 0 :
	subprocess.call(['chmod', '777', '-R', rutaacestream])
else :
	rutabinario = os.path.join(rutaacestream, "chroot") 
	st = os.stat(rutabinario)
	os.chmod(rutabinario, st.st_mode | stat.S_IEXEC)
	subprocess.call(['sudo', 'chmod', '777', '-R', rutaacestream])

pDialog.update(75, "Limpiando Archivos...")


""" ELIMINAR ARCHIVOS"""


time.sleep(1)
from os import remove
if "arm" in os.uname()[4]:
	remove(ruta+'/userdata/acestream.zip')
	pDialog.update(100, "Acestream Modificado con Exito!")
	time.sleep(2)
else:
	remove(ruta+'/acestream1.zip')
	pDialog.update(100, "Acestream Modificado con Exito!, Reiniciando...")
	time.sleep(4)
	os.system('reboot')
