#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
#     Copyright (C) 2016 Taifxx
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
########## VPlus:
import urllib 
import time, datetime
import os, sys, re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs


ID = "context.videotecaplus"
ADDON = xbmcaddon.Addon(ID)
PATH = ADDON.getAddonInfo('path')

PATTERNS_FOR_DELETE = ADDON.getSetting('patterns_delete') if ADDON.getSetting('patterns_delete') else "[(].+?[)],[[].+?[]]"

IS_EDIT = ADDON.getSetting('is_edit') if ADDON.getSetting('is_edit') else "false"

Categorias = ["SERIES","TEMPORADA","CINE"]
DIRECTORY = xbmc.translatePath(ADDON.getSetting('directory'))

def addon_log(msg, level=xbmc.LOGNOTICE):
    log_message = u'{0}: {1}'.format(ID, msg)
    xbmc.log(log_message.encode("utf-8"), level) 

def generate():

	category = select_category()
	if category == None:
		return
	media_title = get_media_title()
	if (media_title == None) or (media_title == ""):
		return
	uri = xbmc.getInfoLabel('ListItem.FileNameAndPath')
	if category == Categorias[1]:
		foldername = xbmc.getInfoLabel('ListItem.Label')
		foldername =cleanLabels(foldername)
	else:
		foldername = None
	id_select = xbmc.getInfoLabel('ListItem.SetId')
	uri2 = xbmc.getInfoLabel('ListItem.Path')
	uri3 = xbmcgui.getCurrentWindowDialogId()
	fillPluginItems(uri, category, media_title, foldername)
	message = "'%s'" % media_title
	xbmc.executebuiltin('XBMC.UpdateLibrary(video)')
	xbmc.executebuiltin("Notification(\"Agregado a Videoteca Plus\", \"%s\")" % message)

def select_category():
	category = None
	if Categorias != None:
		ret = xbmcgui.Dialog().select("Selecciona una categoría", Categorias)
		if ret >= 0:
			category = Categorias[ret] 
	return category

def get_media_title():
    title = get_title()
    year = get_media_year(title)
    patterns = PATTERNS_FOR_DELETE.split(",") if PATTERNS_FOR_DELETE else []
    for pattern in patterns:
        title = re.compile(decode_(pattern)).sub("", title).strip()
    title = title.replace(":", ".").split("/")[0].strip()
    if year:
        title = "{0} [{1}]".format(title.encode('utf-8'), year)
    title = edit_title(title) 
    return title

def get_title():
    title = xbmc.getInfoLabel("ListItem.Title") if xbmc.getInfoLabel("ListItem.Title") else xbmc.getInfoLabel("ListItem.Label")
    return decode_(title)
	
def decode_(param):
    try:
        return param.decode('utf-8')
    except:
        return param
	
def get_media_year(title):
    year = xbmc.getInfoLabel('ListItem.Year')
    if year:
        return year
    else:    
        pattern = r"[([]([12][90]\d\d)[]), ]"
        match = re.compile(decode_(pattern)).search(title)
        return match.group(1) if match else None

def edit_title(title):
    if check_is_edit(title) == True:
        kbd = xbmc.Keyboard()
        kbd.setDefault(title)
        kbd.setHeading('Editar título')
        kbd.doModal()
        if kbd.isConfirmed():
            title = kbd.getText()
        else: 
            title = ""
    return title

def check_is_edit(title):
    isedit = False
    if IS_EDIT == "true":
        isedit = True
    return isedit

def ascii(string):
    if isinstance(string, basestring):
        if isinstance(string, unicode):
			string = string.decode('some_encoding').encode('ascii', 'ignore')
    return string
	
def removeNonAscii(s):
	return "".join(filter(lambda x: ord(x)<128, s))

def uni(string):
    if isinstance(string, basestring):
        if isinstance(string, unicode):
           string = string.decode('some_encoding').encode('utf-8', 'ignore' )
    return string

def requestItem(file, fletype='video'):
    addon_log("requestItem") 
    json_query = ('{"jsonrpc":"2.0","method":"Player.GetItem","params":{"playerid":1,"properties":["thumbnail","fanart","title","year","mpaa","imdbnumber","description","season","episode","playcount","genre","duration","runtime","showtitle","album","artist","plot","plotoutline","tagline","tvshowid"]}, "id": 1}')
    json_folder_detail = sendJSON(json_query)
    return re.compile( "{(.*?)}", re.DOTALL ).findall(json_folder_detail)
          
def requestList(path, fletype='video'):
    addon_log("requestList, path = " + str(path)) 
    json_query = ('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "%s", "media": "%s", "properties":["thumbnail","fanart","title","year","mpaa","imdbnumber","description","season","episode","playcount","genre","duration","runtime","showtitle","album","artist","plot","plotoutline","tagline","tvshowid"]}, "id": 1}'%(path,fletype))
    json_folder_detail = sendJSON(json_query)
    return re.compile( "{(.*?)}", re.DOTALL ).findall(json_folder_detail)   

def sendJSON(command):
    data = ''
    try:
        data = xbmc.executeJSONRPC(uni(command))
    except UnicodeEncodeError:
        data = xbmc.executeJSONRPC(ascii(command))
    return uni(data)
	
def cleanStrms( text, format=''):
	text = uni(text)
	text = text.replace('Full Episodes', '')
	if format == 'title':
		text = text.title().replace("'S","'s")
	elif format == 'upper':
		text = text.upper()
	elif format == 'lower':
		text = text.lower()
	else:
		text = text
	return text

def cleanLabels(text, format=''):
	text = uni(text)
	text = re.sub('\[COLOR (.+?)\]', '', text)
	text = re.sub('\[/COLOR\]', '', text)
	text = re.sub('\[COLOR=(.+?)\]', '', text)
	text = re.sub('\[color (.+?)\]', '', text)
	text = re.sub('\[/color\]', '', text)
	text = re.sub('\[Color=(.+?)\]', '', text)
	text = re.sub('\[/Color\]', '', text)
	text = text.replace("[]",'')
	text = text.replace("[UPPERCASE]",'')
	text = text.replace("[/UPPERCASE]",'')
	text = text.replace("[LOWERCASE]",'')
	text = text.replace("[/LOWERCASE]",'')
	text = text.replace("[B]",'')
	text = text.replace("[/B]",'')
	text = text.replace("?",'')
	text = text.replace("[I]",'')
	text = text.replace("[/I]",'')
	text = text.replace('[D]','')
	text = text.replace('[F]','')
	text = text.replace("[CR]",'')
	text = text.replace("[HD]",'')
	text = text.replace("()",'')
	text = text.replace("[CC]",'')
	text = text.replace("[Cc]",'')
	text = text.replace("[Favorite]", "")
	text = text.replace("[DRM]", "")
	text = text.replace('(cc).','')
	text = text.replace('(n)','')
	text = text.replace("(SUB)",'')
	text = text.replace("(DUB)",'')
	text = text.replace('(repeat)','')
	text = text.replace("(English Subtitled)", "")    
	text = text.replace("*", "")
	text = text.replace("\n", "")
	text = text.replace("\r", "")
	text = text.replace("\t", "")
	text = text.replace("\ ",'')
	text = text.replace("/ ",'')
	text = text.replace("\\",'/')
	text = text.replace("//",'/')
	text = text.replace('plugin.video.','')
	text = text.replace('plugin.audio.','')
	text = re.sub('[\/:*?<>|!@#$/:]', '', text)
	if format == 'title':
		text = text.title().replace("'S","'s")
	elif format == 'upper':
		text = text.upper()
	elif format == 'lower':
		text = text.lower()
	else:
		text = text
	text = uni(text.strip())
	return text

def fillPluginItems(uri, category, media_title, foldername=None, media_type='video', file_type=False, strm=False, strm_name=''):
	lista_links =[]
	if not file_type:
		detail = uni(requestList(uri, media_type))
	else:
		detail = uni(requestItem(uri, media_type))
	for f in detail:
		vuelta = str(detail.index(f))
		files = re.search('"file" *: *"(.*?)",', f)
		filetypes = re.search('"filetype" *: *"(.*?)",', f)
		labels = re.search('"label" *: *"(.*?)",', f)
		thumbnails = re.search('"thumbnail" *: *"(.*?)",', f)
		fanarts = re.search('"fanart" *: *"(.*?)",', f)
		descriptions = re.search('"description" *: *"(.*?)",', f)
		if filetypes and labels and files:
			filetype = filetypes.group(1)
			label = cleanLabels(labels.group(1))
			file = (files.group(1).replace("\\\\", "\\"))

			if filetype == "directory" and category == Categorias[0]:
				detail_2 = uni(requestList(file, media_type))
				for capitulos in detail_2:
					files_2 = re.search('"file" *: *"(.*?)",', capitulos)
					filetypes_2 = re.search('"filetype" *: *"(.*?)",', capitulos)
					labels_2 = re.search('"label" *: *"(.*?)",', capitulos)
					thumbnails_2 = re.search('"thumbnail" *: *"(.*?)",', capitulos)
					fanarts_2 = re.search('"fanart" *: *"(.*?)",', capitulos)
					descriptions_2 = re.search('"description" *: *"(.*?)",', capitulos)
					if filetypes_2 and labels_2 and files_2:
						filetype_cap = filetypes_2.group(1)
						label_cap = cleanLabels(labels_2.group(1))
						file_cap = (files_2.group(1).replace("\\\\", "\\"))
						if filetype_cap == "file":
							filepath = os.path.join(DIRECTORY,str(category),str(media_title), label + ' - ' + vuelta) 
							filename = label_cap
							makeSTRM(filepath, filename, file_cap)
						if filetype_cap == "directory":
							for capitulos in detail_2:
								files_2 = re.search('"file" *: *"(.*?)",', capitulos)
								filetypes_2 = re.search('"filetype" *: *"(.*?)",', capitulos)
								labels_2 = re.search('"label" *: *"(.*?)",', capitulos)
								thumbnails_2 = re.search('"thumbnail" *: *"(.*?)",', capitulos)
								fanarts_2 = re.search('"fanart" *: *"(.*?)",', capitulos)
								descriptions_2 = re.search('"description" *: *"(.*?)",', capitulos)
								if filetypes_2 and labels_2 and files_2:
									filetype_cap = filetypes_2.group(1)
									label_cap = cleanLabels(labels_2.group(1))
									file_cap = (files_2.group(1).replace("\\\\", "\\"))
									if filetype_cap == "file":
										filepath = os.path.join(DIRECTORY,str(category),str(media_title), label + ' - ' + vuelta) 
										filename = label_cap
										makeSTRM(filepath, filename, file_cap)
			if filetype == "file" and category == Categorias[0]:
				filepath = os.path.join(DIRECTORY,str(category),str(media_title), label) 
				filename = label + ' - ' + vuelta
				makeSTRM(filepath, filename, file)
			
			if filetype == "file" and category == Categorias[1]:
				filepath = os.path.join(DIRECTORY,str(Categorias[0]),str(media_title),foldername.encode('utf-8')) 
				filename = label
				makeSTRM(filepath, filename, file)
				
			if filetype == "file" and category == Categorias[2]:
				filepath = os.path.join(DIRECTORY,category.encode('utf-8'),media_title) 
				filename = str(media_title) +' - '+vuelta
				makeSTRM(filepath, filename, file)
		if str(filetypes) == 'None' and category == Categorias[2]:
			xbmc.log('[INFO VIDEOTECAPLUS]  ' + category.encode('utf-8'),xbmc.LOGNOTICE)
			filepath = os.path.join(DIRECTORY,category.encode('utf-8'),media_title)
			filename = media_title
			makeSTRM(filepath, filename, uri.replace("\\\\", "\\"))

	if category == Categorias[1]:
		carpeta = os.path.join(DIRECTORY,Categorias[0],media_title)
		xbmc.log('[INFO VIDEOTECAPLUS]  ' + carpeta,xbmc.LOGNOTICE)
	else:
		carpeta = os.path.join(DIRECTORY,category.encode('utf-8'),media_title)
	actualizador = os.path.join(carpeta, media_title + '.txt')
	xbmc.log('[INFO VIDEOTECAPLUS]  ' + actualizador,xbmc.LOGNOTICE)
	if xbmc.getCondVisibility('system.platform.windows') == 1:
		fle = open(actualizador.decode('utf-8'), "w")
	else:
		fle = open(actualizador, "w")
	if foldername == None:
		fle.write(media_title + ";" + category.encode('utf-8') + ";" + uri)
	else:
		fle.write(media_title + ";" + category.encode('utf-8') + ";" + uri + ";" + foldername.encode('utf-8'))
	fle.close()

def makeSTRM(filepath, filename, file_cap):
	addon_log('makeSTRM')
	if not xbmcvfs.exists(filepath): 
		xbmcvfs.mkdirs(filepath)
	fullpath = os.path.join(filepath, filename + '.strm')
	if xbmcvfs.exists(fullpath):
		return fullpath
	else:
		if xbmc.getCondVisibility('system.platform.windows') == 1:
			fle = open(fullpath.decode('utf-8'), "w")
		else:
			fle = open(fullpath, "w")
		fle.write("%s" % file_cap)
		fle.close()

def main():
	generate()

if __name__ == '__main__':
	main()