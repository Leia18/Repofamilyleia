#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
#     Copyright (C) 2016 VPlus
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
########## updater:
import urllib 
import time, datetime
import sys, re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
import os
from default import fillPluginItems

ID = "context.videotecaplus"
ADDON = xbmcaddon.Addon(ID)
PATH = ADDON.getAddonInfo('path')

PATTERNS_FOR_DELETE = ADDON.getSetting('patterns_delete') if ADDON.getSetting('patterns_delete') else "[(].+?[)],[[].+?[]]"

IS_EDIT = ADDON.getSetting('is_edit') if ADDON.getSetting('is_edit') else "false"

Categorias = ["SERIES","TEMPORADAS","CINE"]
DIRECTORY = xbmc.translatePath(ADDON.getSetting('directory'))

for [ruta,directorios,archivos] in os.walk(DIRECTORY, topdown=True):
    for archivo in archivos:
        if archivo.endswith(".txt"):
			leer_txt = open(ruta+'/'+archivo,"r")
			lista = str(leer_txt.read()).split(';')
			if len(lista) == 4:
				[media_title,category,uri,foldername] = lista
				fillPluginItems(uri, category, media_title,foldername)
			if len(lista) == 3:
				[media_title,category,uri] = lista
				xbmc.log('ANTES DE ENTRAR CON SERVICE  ' + category,xbmc.LOGNOTICE)
				fillPluginItems(uri, category.decode('utf-8'), media_title)
xbmc.executebuiltin('XBMC.UpdateLibrary(video)')